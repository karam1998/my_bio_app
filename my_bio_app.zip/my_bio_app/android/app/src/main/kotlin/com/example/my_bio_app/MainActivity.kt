package com.example.my_bio_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
